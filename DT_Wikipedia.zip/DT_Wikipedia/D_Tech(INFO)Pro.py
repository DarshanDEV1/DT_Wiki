from tkinter import *
login = Tk()
import wikipedia
import tkinter as tk
import os
from tkinter.filedialog import askopenfilename, asksaveasfilename
import pyttsx3
engine = pyttsx3.init()
voice = engine.getProperty('voices')
engine.setProperty('voice',voice[1].id)
engine.say("Hello , I am Jarvalpha , your study partner , Welcome to D TECH")
engine.runAndWait()
engine.say("Please enter the user name and password to login")
engine.runAndWait()

# photo = PhotoImage(file="C:\\Users\\BEDAPRAKASH\\Downloads\\D_Tech_Logo.png")
login.config(bg="ghostwhite")
login.title("Darshan's Technologies")
# login.iconphoto(False,photo)
login.minsize(600,400)
login.maxsize(600,400)
l = Label(login,text="Darshan's Technologies(D.TECH)",font=("Stencil 20 bold underline"),bg="white",fg="black")
l.pack()
l_sub = Label(login,text="IMAGINATION ENDS AND IMPLIMENTATION BEGINS",font=("Sketch 10 underline italic"),bg="white",fg="black")
l_sub.pack()
l_1 = Label(text="User ID : ",bg="black",fg="white")
l_1.place(x=180,y=60)
strvar = StringVar()
entry = Entry(login,textvariable=strvar,width="20",bg="grey",fg="white")
entry.pack()
l_2 = Label(text="Password : ",bg="black",fg="white")
l_2.place(x=168,y=97)
strvar_password = StringVar()
strvar_password = Entry(login,textvariable=strvar_password,width="20",bg="grey",fg="white")
strvar_password.pack(pady=20)
def submit_s(event):
	if f"{strvar_password.get()}"  == "Darshan" and f"{strvar.get()}" == "Darshan":
		print("Succesfully logged in")
		print("User ID : " + str(f"{strvar.get()}"))
		print("Password : " + str(f"{strvar_password.get()}"))
		l_sub.config(text="Succesfully Logged in",bg="green",fg="black",font=("Stencil 10 bold"))
		# login.config(bg="navy")
		login.destroy()
		# Logic here
		class main:
			def main_window():
				c.destroy()
				# root = Tk()
				# root.title("Darshan's Technologies_Welcome window")
				# root.config(bg="white")
				# photo_root = PhotoImage(file="C:\\Users\\BEDAPRAKASH\\Downloads\\DTech_Logo.png")
				# bgr = "white"
				# fgr = "black"
				# root.iconphoto(False,photo_root)
				# l = Label(root,text="Darshan's Technologies(D.TECH)",font=("Stencil 20 bold underline"),bg="white",fg="black")
				# l.pack()
				# l_sub = Label(root,text="IMAGINATION ENDS AND IMPLIMENTATION BEGINS",font=("Sketch 10 underline italic"),bg="white",fg="black")
				# l_sub.pack()
				# root.mainloop()


				# from tkinter import *
				root = Tk()
				# p = PhotoImage(file="C:\\Users\\BEDAPRAKASH\\Desktop\\D_Tech_Logo.png")
				# root.iconphoto(False , p)
				root.minsize(1000,500)
				root.maxsize(1000,550)
				# import wikipedia
				root.title("Darshan's Technologies")
				root.config(bg="navy")
				bgcol = "navy"
				Label(root,text="Darshan's Technologies(D.TECH)",font=("Stencil 30 bold underline"),bg=bgcol,fg="white").pack()
				Label(root,text="IMAGINAITON ENDS IMPLEMENTATION BEGINS",font=("Stencil 15 bold underline"),bg=bgcol,fg="white").pack()
				t = Text(root,width=190,height=20,bg=bgcol,fg="white")
				t.pack()
				usr = StringVar()
				l = Label(root,text="Keyword: ",bg=bgcol,fg="red",font="Times 10")
				l.place(x=341,y=410)
				e = Entry(root,textvariable=usr,bg=bgcol,fg="white")
				e.pack()
				l1 = Label(root,text="No. of lines: ",bg=bgcol,fg="red",font="Times 10")
				l1.place(x=330,y=425)
				i = IntVar()
				i_ = Entry(root,textvariable=i,bg=bgcol,fg="white")
				i_.pack()
				def click(event):
					r = wikipedia.summary(f"{usr.get()}",f"{i.get()}")
					t.insert(1.0,r)
				def reset(event):
					t.delete("1.0","end")
				b1 = Button(root,text="search",bg=bgcol,fg="white",bd=5,command=click)
				b1.bind("<Return>",click)
				b1.pack()
				b2 = Button(root,text="reset",bg=bgcol,fg="white",bd=5,command=reset)
				b2.bind("<Return>",reset)
				b2.pack()
				b3 = Button(root,text="end",bg=bgcol,fg="white",bd=5,command=root.destroy)
				b3.pack()
				root.mainloop()



			def text_editor():
				c.destroy()
				# engine = pyttsx3.init()
				# voice = engine.getProperty('voices')
				# engine.setProperty('voice',voice[1].id)
				# engine.say("Hello , I am Jarvalpha , your study partner , Welcome to D TECH")
				# engine.runAndWait()
				def open_file():
				    """Open a file for editing."""
				    filepath = askopenfilename(
				        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
				    )
				    if not filepath:
				        return
				    txt_edit.delete(1.0, tk.END)
				    with open(filepath, "r") as input_file:
				        text = input_file.read()
				        txt_edit.insert(tk.END, text)
				    window.title(f"Darshan's Technologies(D.Tech) - {filepath}")

				def save_file():
				    """Save the current file as a new file."""
				    filepath = asksaveasfilename(
				        defaultextension="txt",
				        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
				    )
				    if not filepath:
				        return
				    with open(filepath, "w") as output_file:
				        text = txt_edit.get(1.0, tk.END)
				        output_file.write(text)
				    window.title(f"Darshan's Technologies(D.Tech) - {filepath}")

				window = tk.Tk()
				window.title("Darshan's Technologies(D.Tech)")
				window.config(bg="wheat")
				# p = PhotoImage(file="C:\\Users\\BEDAPRAKASH\\Desktop\\D_Tech_Logo.png")
				# window.iconphoto(False , p)
				window.rowconfigure(0, minsize=800, weight=1)
				window.columnconfigure(1, minsize=800, weight=1)

				txt_edit = tk.Text(window,font=("Sketch",12))
				fr_buttons = tk.Frame(window, relief=tk.RAISED, bd=2)
				btn_open = tk.Button(fr_buttons, text="Open", command=open_file)
				btn_save = tk.Button(fr_buttons, text="Save As...", command=save_file)

				btn_open.grid(row=0, column=0, sticky="ew", padx=5, pady=5)
				btn_save.grid(row=1, column=0, sticky="ew", padx=5)

				fr_buttons.grid(row=0, column=0, sticky="ns")
				txt_edit.grid(row=0, column=1, sticky="nsew")

				def powershell():
				    os.startfile('C:\\Windows\\System32\\cmd.exe')
				btn = tk.Button(fr_buttons,text="terminal",command=powershell)
				# btn.bind("<Control-slash>",powershell)
				btn.grid(row=2,column=0,sticky="ew",padx=5)

				window.mainloop()


		def main_call():
			obj = main
			obj.main_window()
		def text_editor_call():
			obj_1 = main
			obj_1.text_editor()
		c = Tk()
		c.config(bg="wheat")
		Label(c,text="Darshan's Technologies(D.TECH)",font=("Stencil 30 bold underline"),bg="wheat",fg="white").pack()
		Label(c,text="IMAGINAITON ENDS IMPLEMENTATION BEGINS",font=("Stencil 15 bold underline"),bg="wheat",fg="white").pack()
		# p = PhotoImage(file="C:\\Users\\BEDAPRAKASH\\Desktop\\D_Tech_Logo.png")
		# c.iconphoto(False , p)
		c.title("Darshan Technologies(D.Tech)_Choose_window")
		btn1 = Button(text="InfoTech",bg="black",fg="white",bd=6,command=main_call)
		btn1.pack()
		btn2 = Button(text="TextEditor",bg="black",fg="white",bd=6,command=text_editor_call)
		btn2.pack()
		c.mainloop()

	else:
		print("Try Again")
		l_sub.config(text="Try Again",bg="red",fg="black",font=("Stencil 10 bold"))
Submit = Button(login,text="submit",bd=5,command=submit_s)
Submit.bind("<Return>",submit_s)
Submit.pack()
End = Button(login,text="exit",bd=5,command=login.destroy)
End.pack()
def dark_theme_d(event):
	login.config(bg="black")
	l.config(bg="black",fg="white")
	l_sub.config(bg="black",fg="white")
	l_1.config(bg="white")
	l_2.config(bg="white")
def normal_theme_n(event):
	login.config(bg="white")
	l.config(bg="white",fg="black")
	l_sub.config(bg="white",fg="black")
	l_1.config(bg="white",fg="black")
	l_2.config(bg="white",fg="black")
dark_theme = Button(login,text="Dark Theme",bg="black",bd=5,fg="white",command=dark_theme_d)
dark_theme.bind("<Return>",dark_theme_d)
dark_theme.pack(side="right")
normal_theme = Button(login,text="Normal Theme",bg="white",bd=5,fg="black",command=normal_theme_n)
normal_theme.bind("<Return>",normal_theme_n)
normal_theme.pack(side="left")
login.mainloop()
